
Para ejecutar el demo ejecute:

    $ php -S localhost:8000 -t tests/public

Seguidamente acceda a la respectiva URL.