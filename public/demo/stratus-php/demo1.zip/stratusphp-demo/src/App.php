<?php

namespace ThenLabs\StratusPHP\Demo;

use ThenLabs\StratusPHP\AbstractApp;

class App extends AbstractApp
{
    public function getView(): string
    {
        return <<<HTML
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>Document</title>
            </head>
            <body>
                <input type="" name="">
                <label></label>
                <button>Saludar</button>
            </body>
            </html>
        HTML;
    }
}