<?php

require_once __DIR__.'/../vendor/autoload.php';

use ThenLabs\StratusPHP\Demo\App;
use function Opis\Closure\serialize as s;

$app = new App('/controller.php');

$input = $app->querySelector('input');
$label = $app->querySelector('label');
$button = $app->querySelector('button');

$button->click(function () use ($input, $label) {
    $label->innerHTML = "Hola {$input->value}";
});

session_start();
$_SESSION['app'] = s($app);

echo $app;